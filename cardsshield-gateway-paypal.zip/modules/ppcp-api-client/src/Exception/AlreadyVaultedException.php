<?php
/**
 * AlreadyVaultedException.
 *
 * @package WooCommerce\MecomPaypal\ApiClient\Exception
 */

declare(strict_types=1);

namespace WooCommerce\MecomPaypal\ApiClient\Exception;

/**
 * Class AlreadyVaultedException
 */
class AlreadyVaultedException extends RuntimeException {
}
