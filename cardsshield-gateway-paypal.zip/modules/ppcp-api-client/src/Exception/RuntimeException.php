<?php
/**
 * The modules runtime exception.
 *
 * @package WooCommerce\MecomPaypal\ApiClient\Exception
 */

declare(strict_types=1);

namespace WooCommerce\MecomPaypal\ApiClient\Exception;

/**
 * Class RuntimeException
 */
class RuntimeException extends \RuntimeException {


}
