<?php
/**
 * Feed Making View
 *
 * @link       https://webappick.com/
 * @since      1.0.0
 *
 * @package    Woo_Feed
 * @subpackage Woo_Feed/admin/partial
 * @author     Ohidul Islam <wahid@webappick.com>
 */

use CTXFeed\V5\Utility\Config;

if ( ! defined( 'ABSPATH' ) ) {
	die();
}
/** @define "WOO_FEED_PRO_ADMIN_PATH" "./../" */
/**
 * globals
 *
 * @global array $feedRules
 * @global Woo_Feed_Dropdown_Pro $wooFeedDropDown
 * @global Woo_Feed_Merchant_Pro $merchant
 * @global string $feedName
 * @global int $feedId
 * @global string $provider
 * @global array $wp_meta_boxes
 */
global $feedRules, $wooFeedDropDown, $merchant, $feedName, $feedId, $provider, $wp_meta_boxes;
$feedName          = '';
$feedId            = '';
$wf_current_screen = get_current_screen();
$wf_page           = $wf_current_screen->id;
$wooFeedDropDown   = new Woo_Feed_Dropdown_Pro();
$feedRules         = woo_feed_parse_feed_rules( $feedRules );
woo_feed_register_and_do_woo_feed_meta_boxes( $wf_current_screen, $feedRules );



?>
<div class="wrap wapk-admin" id="Feed">
	<div class="wapk-section">
        <h1 class="wp-heading-inline"><?php esc_html_e( 'New Product Feed', 'woo-feed' ); ?></h1>
        <?php WPFFWMessage()->displayMessages(); ?></div>
	<hr class="wp-header-end">
	<div class="wapk-section">
		<form action="" name="feed" id="generateFeed" class="generateFeed add-new" method="post" autocomplete="off">
			<input type="hidden" name="feed_option_name" value="">
			<input type="hidden" name="feed_id" value="">
			<?php
			wp_nonce_field( 'woo_feed_form_nonce' );
			wp_nonce_field( 'closedpostboxes', 'closedpostboxesnonce', false );
			wp_nonce_field( 'meta-box-order', 'meta-box-order-nonce', false );
			?>
			<div id="poststuff">
				<div id="post-body" class="metabox-holder columns-<?php echo 1 == get_current_screen()->get_columns() ? '1' : '2'; ?>">
					<div id="post-body-content">
						<?php require_once WOO_FEED_PRO_ADMIN_PATH . 'partials/woo-feed-content-settings.php'; ?>
					</div>
					<div id="postbox-container-1" class="postbox-container">
						<?php do_meta_boxes( get_current_screen(), 'side', $feedRules ); ?>
					</div>
				</div>
				<div class="clear"></div>
				<div id="providerPage"></div>
			</div>
		</form>
	</div>
</div><!-- /wrap -->
