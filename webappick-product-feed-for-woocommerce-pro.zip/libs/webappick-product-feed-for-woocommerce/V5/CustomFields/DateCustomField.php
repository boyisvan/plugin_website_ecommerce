<?php

namespace CTXFeed\V5\CustomField;


/**
 * Class DateCustomField
 *
 * @package    CTXFeed\V5\CustomField
 * @subpackage CTXFeed\V5\CustomField
 */
class DateCustomField {
	
}