<?php
namespace CTXFeed\V5\Tracker;
class SnapchatTracker implements TrackerInterface {

	public function is_activated() {
		// TODO: Implement is_activated() method.
	}

	public function enqueueScript() {
		// TODO: Implement enqueueScript() method.
	}

	public function loadBaseScript() {
		// TODO: Implement loadBaseScript() method.
	}

	public function triggerEvents() {
		// TODO: Implement triggerEvents() method.
	}
}