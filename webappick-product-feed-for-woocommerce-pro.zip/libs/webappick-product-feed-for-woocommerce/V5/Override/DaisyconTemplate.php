<?php

namespace CTXFeed\V5\Override;


/**
 * Class DaisyconTemplate
 *
 * @package    CTXFeed\V5\Override
 * @subpackage CTXFeed\V5\Override
 */
class DaisyconTemplate {
	
}