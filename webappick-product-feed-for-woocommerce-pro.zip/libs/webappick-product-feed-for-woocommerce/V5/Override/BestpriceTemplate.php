<?php

namespace CTXFeed\V5\Override;


/**
 * Class BestpriceTemplate
 *
 * @package    CTXFeed
 * @subpackage CTXFeed\V5\Override
 */
class BestpriceTemplate {
	
}