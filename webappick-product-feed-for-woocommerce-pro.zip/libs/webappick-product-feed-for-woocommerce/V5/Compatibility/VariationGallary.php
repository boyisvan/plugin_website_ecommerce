<?php

namespace CTXFeed\V5\Compatibility;

class VariationGallary {

}