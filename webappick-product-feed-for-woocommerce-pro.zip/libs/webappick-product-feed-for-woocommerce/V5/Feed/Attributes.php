<?php

namespace CTXFeed\V5\Feed;


/**
 * Class ProductAttribute
 *
 * @package    CTXFeed
 * @subpackage CTXFeed\V5\Feed
 * @author     Ohidul Islam <wahid0003@gmail.com>
 * @link       https://webappick.com
 * @license    https://opensource.org/licenses/gpl-license.php GNU Public License
 * @category   MyCategory
 */
class Attributes {
	/**
	 * @return void
	 */
	public static function getAttributes(  ) {

	}

	/**
	 * @return void
	 */
	public static function saveAttributes(  ) {

	}

	/**
	 * @return void
	 */
	public static function updateAttributes(  ) {

	}
}
