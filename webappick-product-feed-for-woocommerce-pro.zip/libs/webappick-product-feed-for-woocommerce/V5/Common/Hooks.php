<?php

namespace CTXFeed\V5\Common;

class Hooks {

}
