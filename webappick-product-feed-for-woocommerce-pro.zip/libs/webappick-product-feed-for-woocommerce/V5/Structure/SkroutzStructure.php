<?php

/**
 * Class Skroutz
 *
 * @package    CTXFeed
 * @subpackage CTXFeed\V5\Structure
 */

namespace CTXFeed\V5\Structure;

class Skroutz {

}
