<?php

/**
 * Class TiktokStructure
 *
 * @package    CTXFeed
 * @subpackage CTXFeed\V5\Structure
 */

namespace CTXFeed\V5\Structure;

class TiktokStructure {

}
