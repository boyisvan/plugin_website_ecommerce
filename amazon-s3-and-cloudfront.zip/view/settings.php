<div id="as3cf-settings" class="wpome">
</div>

<script>
	new AS3CF_Settings( {
		target: document.getElementById( 'as3cf-settings' ),
		props: {
			init: as3cf_settings
		}
	} );
</script>
