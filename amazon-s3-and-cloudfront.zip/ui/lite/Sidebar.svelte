<script>
	import {urls} from "../js/stores";
</script>

<div class="as3cf-sidebar lite">
	<a class="as3cf-banner" href={$urls.sidebar_plugin}>
	</a>
	<div class="as3cf-upgrade-details">
		<h1>Upgrade</h1>
		<h2>Gain access to more features when you upgrade to WP Offload Media</h2>
		<ul>
			<li>Email support</li>
			<li>Offload existing media items</li>
			<li>Manage offloaded files in WordPress</li>
			<li>Serve assets like JS, CSS, and fonts from CloudFront or another CDN</li>
			<li>Deliver private media via CloudFront</li>
			<li>Offload media from popular plugins like WooCommerce, Easy Digital Downloads, BuddyBoss, and more</li>
		</ul>
	</div>
	<div class="subscribe">
		<h2>Get up to 40% off your first year of WP Offload Media!</h2>
		<a href={$urls.sidebar_discount} class="button btn-lg btn-primary">Get the discount</a>
		<p class="discount-applied">* Discount applied automatically.</p>
	</div>
</div>
