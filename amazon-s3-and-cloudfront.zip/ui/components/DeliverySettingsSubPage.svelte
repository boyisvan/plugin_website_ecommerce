<script>
	import SubPage from "./SubPage.svelte";
	import DeliverySettingsPanel from "./DeliverySettingsPanel.svelte";
</script>

<SubPage name="delivery-settings" route="/media/delivery">
	<DeliverySettingsPanel/>
</SubPage>
