<script>
	import SubPage from "./SubPage.svelte";
	import StorageSettingsPanel from "./StorageSettingsPanel.svelte";
</script>

<SubPage name="storage-settings">
	<StorageSettingsPanel/>
</SubPage>
