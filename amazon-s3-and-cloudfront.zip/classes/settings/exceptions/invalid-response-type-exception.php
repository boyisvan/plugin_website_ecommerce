<?php

namespace DeliciousBrains\WP_Offload_Media\Settings\Exceptions;

class Invalid_Response_Type_Exception extends Domain_Check_Exception {
}
