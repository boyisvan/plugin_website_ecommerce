<?php

namespace DeliciousBrains\WP_Offload_Media\Settings\Exceptions;

class S3_Bucket_Origin_Exception extends Domain_Check_Exception {
}
