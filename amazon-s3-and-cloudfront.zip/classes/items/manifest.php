<?php

namespace DeliciousBrains\WP_Offload_Media\Items;

class Manifest {
	/**
	 * @var array
	 */
	public $objects = array();
}