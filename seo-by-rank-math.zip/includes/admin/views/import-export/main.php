<?php
/**
 * Import/Export page template.
 *
 * @package    RankMath
 * @subpackage RankMath\Admin
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="rank-math-import-export">
	<?php $this->show_panels(); ?>
</div>
