<?php return array('dependencies' => array('wp-hooks', 'wp-i18n'), 'version' => '8e5a56976d5c8065575f');
