<?php return array('dependencies' => array(), 'version' => 'd328580771c8363d4991');
