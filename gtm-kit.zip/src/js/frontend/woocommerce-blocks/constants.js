export const namespace = 'gtmkit-woocommerce-google-analytics';

export const actionPrefix = 'experimental__woocommerce_blocks';
