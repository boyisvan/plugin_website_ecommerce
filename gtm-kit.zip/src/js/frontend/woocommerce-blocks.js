/**
 * GTM Kit
 */

import './woocommerce-blocks/index';
