/**
 * GTM Kit
 */

import './event-inspector/index';
