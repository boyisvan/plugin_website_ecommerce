function removeShortcode() {
    jQuery("#fifu_shortcode").hide();
    jQuery("#fifu_shortcode_link").hide();

    jQuery("#fifu_shortcode_input").val("");
}