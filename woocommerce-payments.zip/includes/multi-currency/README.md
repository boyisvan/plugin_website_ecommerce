# WooPayments multi-currency directory

This directory contains the multi-currency module, which has been decoupled and extracted from the gateway code.

The module is responsible for handling all multi-currency functionality, both back-end and front-end.
