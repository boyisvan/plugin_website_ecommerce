import { createSlotFill } from '@wordpress/components';

const { Slot: BeforeHeaderSlot, Fill: BeforeHeaderFill } = createSlotFill( 'BeforeHeader' );
export { BeforeHeaderSlot, BeforeHeaderFill };
