/**
 * External dependencies
 */
import styled from '@emotion/styled';

export const StyledGlobalSettingsContainer = styled.div`
	margin-top: 1.5rem;
`;
