export const STORE_NAME = 'ithemes-security/site-scan-ui';

export const STATUS_WAITING = 'waiting';
export const STATUS_BUSY = 'busy';
export const STATUS_DONE = 'done';
export const STATUS_FAILED = 'failed';
