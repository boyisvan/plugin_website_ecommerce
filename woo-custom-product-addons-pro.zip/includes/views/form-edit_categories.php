<?php
wp_category_checklist();