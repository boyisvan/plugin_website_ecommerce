<?php
if (!defined('ABSPATH'))
    exit;

class WCPA_Settings
{

    /**
     * @var    object
     * @access  private
     * @since    1.0.0
     */
    private static $_instance = null;

    /**
     * The version number.
     * @var     string
     * @access  public
     * @since   1.0.0
     */
    public $_version;

    /**
     * The token.
     * @var     string
     * @access  public
     * @since   1.0.0
     */
    public $_token;

    /**
     * The main plugin file.
     * @var     string
     * @access  public
     * @since   1.0.0
     */
    public $file;
    private $settings = array();

    public function __construct()
    {
        $this->_version = WCPA_VERSION;
        $this->_token = WCPA_TOKEN;
        $this->file = WCPA_FILE;
        $this->dir = dirname($this->file);
        $this->assets_url = esc_url(trailingslashit(plugins_url('/assets/', $this->file)));

        $this->settings = [
            'disp_show_field_price' => 'boolean',
            'disp_summ_show_total_price' => 'boolean',
            'disp_summ_show_product_price' => 'boolean',
            'disp_summ_show_option_price' => 'boolean',
            'show_meta_in_cart' => 'boolean',
            'show_meta_in_checkout' => 'boolean',
            'show_meta_in_order' => 'boolean',
            'show_price_in_cart' => 'boolean',
            'show_price_in_checkout' => 'boolean',
            'show_price_in_order' => 'boolean',
            'show_price_in_order_meta' => 'boolean',
            'pric_exc_product_base_price' => 'boolean',
            'enable_recaptcha' => 'boolean',
            'options_total_label' => 'text',
            'options_product_label' => 'text',
            'total_label' => 'text',
            'fee_label' => 'text',
            'add_to_cart_text' => 'text',
            'form_loading_order_by_date' => 'boolean',
            'use_sumo_selector' => 'boolean',
            'load_all_scripts' => 'boolean',
            'wcpa_show_form_json' => 'boolean',
            'hide_empty_data' => 'boolean',
            'google_map_api_key' => 'text',
            'recaptcha_site_key' => 'text',
            'recaptcha_secret_key' => 'text',
            'price_prefix_label' => 'text',
            'field_option_price_format' => 'text',
            'change_price_as_quantity' => 'boolean'
        ];

        add_action('admin_menu', array($this, 'register_options_page'));
        add_action('init', array($this, 'check_migration'));
        $plugin = plugin_basename($this->file);
        add_filter("plugin_action_links_$plugin", array($this, 'add_settings_link'));
    }

    /**
     *
     *
     * Ensures only one instance of CPO is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @see WordPress_Plugin_Template()
     * @return Main CPO instance
     */
    public static function instance($file = '', $version = '1.0.0')
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self($file, $version);
        }
        return self::$_instance;
    }

    public function add_settings_link($links)
    {
        $settings = '<a href="' . admin_url('options-general.php?page=wcpa_settings') . '">' . __('Settings') . '</a>';
        $products = '<a href="' . admin_url('edit.php?post_type=' . WCPA_POST_TYPE) . '">' . __('Create Forms') . '</a><br><center style="width:275px;color:white;background-color:#02a0d2;border-radius:0px 30px">Custom bởi Đồn Vũ</center>';
        array_push($links, $settings);
        array_push($links, $products);
        return $links;


    }

    public function check_migration()
    {
        $migration = new WCPA_Migration();
        $migration->check();
    }

   
    function register_options_page()
    {

        add_options_page('Custom Product Addons', 'Custom Product Addons', 'manage_options', 'wcpa_settings', array($this, 'options_page'));
    }

 
    public function options_page()
    {


        if (array_key_exists('wcpa_save_settings', $_POST)) {
            $this->save_settings();
        }
        if (array_key_exists('action', $_GET)) {
            if ($_GET['action'] == 'migrate') {
                if (isset($_GET['wcpa_nonce']) && wp_verify_nonce($_GET['wcpa_nonce'], 'wcpa_migration')) {
                    $migration = new WCPA_Migration();
                    $response = $migration->version_migration();
                    WCPA_Backend::view('settings-migration', ['response' => $response]);
                }
            }
        } else if (array_key_exists('view', $_GET)) {
            if ($_GET['view'] == 'migration') {
                WCPA_Backend::view('settings-migration', []);
            }
        } else {
            WCPA_Backend::view('settings-main', ['asset_url' => $this->assets_url]);
        }
    }

    public function save_settings()
    {
        if (isset($_POST['wcpa_save_settings']) && wp_verify_nonce($_POST['wcpa_nonce'], 'wcpa_save_settings')) {
            $settings = get_option(WCPA_SETTINGS_KEY);

            foreach ($this->settings as $key => $type) {
                if ($type == 'text') {
                    if (isset($_POST[$key])) {
                        if ('field_option_price_format' == $key) {
                            if ((strpos($_POST[$key], 'price') !== false)) {
                                $settings[$key] = sanitize_text_field($_POST[$key]);
                            }

                        } else {
                            $settings[$key] = sanitize_text_field($_POST[$key]);
                        }

                    }
                } else if ($type == 'boolean') {
                    if (isset($_POST[$key])) {
                        $settings[$key] = true;
                    } else {
                        $settings[$key] = false;
                    }
                }
            }
            if (isset($_POST['product_custom_field_name'])) {
                $custom_fields_name = $_POST['product_custom_field_name'];
                $custom_fields_value = $_POST['product_custom_field_value'];
                $current_fields = isset($settings['product_custom_fields']) ? $settings['product_custom_fields'] : false;
                if (is_array($current_fields)) {
                    foreach ($current_fields as $key => $val) {

                        $field_value = isset($custom_fields_value[$key]) ? trim($custom_fields_value[$key]) : 0;
                        if (isset($custom_fields_name[$key]) && !empty($custom_fields_name[$key])) {
                            $current_fields[$key] = array(
                                'name' => sanitize_key(trim($custom_fields_name[$key])),
                                'value' => $field_value
                            );
                            unset($custom_fields_name[$key]);
                        } else {
                            unset($current_fields[$key]);
                        }
                    }
                } else {
                    $current_fields = array();
                }
                $count = count($current_fields);
                if (is_array($custom_fields_name)) {
                    foreach ($custom_fields_name as $key => $val) {
                        $count++;
                        $field_value = isset($custom_fields_value[$key]) ? trim($custom_fields_value[$key]) : 0;
                        if (!empty($val)) {
                            $current_fields['cf_' . $count] = array(
                                'name' => sanitize_key(trim($val)),
                                'value' => $field_value
                            );
                        }


                    }
                }

                $settings['product_custom_fields'] = $current_fields;

            }
            update_option(WCPA_SETTINGS_KEY, $settings);
            $ml = new WCPA_Ml();
            if ($ml->is_active()) {
                $ml->settings_to_wpml();
            }

            if (isset($_POST['wcpa_activation_license_key'])) {
                $license = trim(sanitize_text_field($_POST['wcpa_activation_license_key']));
                $old = get_option('wcpa_activation_license_key');
                if ($old && $old != $license) {
                    delete_option('wcpa_activation_license_status'); // new license has been entered, so must reactivate
                }

                update_option('wcpa_activation_license_key', $license);
            }


        }
    }

    /**
     * Cloning is forbidden.
     *
     * @since 1.0.0
     */
    public function __clone()
    {
        _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?'), $this->_version);
    }

    /**
     * Unserializing instances of this class is forbidden.
     *
     * @since 1.0.0
     */
    public function __wakeup()
    {
        _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?'), $this->_version);
    }

}
